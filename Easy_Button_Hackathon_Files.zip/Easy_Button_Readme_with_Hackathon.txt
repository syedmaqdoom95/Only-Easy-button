Easy Button Hackathon Files
----------------------------
Includes:
1. Easy_Button_Presentation_with_Hackathon.pptx
2. easy_button_demo_hackathon.py
3. Easy_Button_Readme_with_Hackathon.txt

How to run:
1. Ensure Python 3 is installed.
2. Run in terminal: python easy_button_demo_hackathon.py
