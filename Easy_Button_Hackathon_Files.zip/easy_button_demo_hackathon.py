#!/usr/bin/env python3
print('Easy Button Hackathon Demo Ready')
